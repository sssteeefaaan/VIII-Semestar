package com.bpredic;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.*;

public class LifeCycleExampleActivity extends Activity {

	// class variables and constants
	public static final String MYPREFSID = "MyPrefs001";
	public static final int actMode = Activity.MODE_PRIVATE;

	TextView txtMsg;
	Button btnFinish;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		btnFinish = (Button) findViewById(R.id.btnFinish);
		txtMsg = (EditText) findViewById(R.id.txtMsg);

		txtMsg.addTextChangedListener(new TextWatcher() {
			public void onTextChanged(CharSequence s, int start, int before,
					int count) {
				// TODO Auto-generated method stub
			}

			public void beforeTextChanged(CharSequence s, int start, int count,
					int after) {
				// TODO Auto-generated method stub
			}

			public void afterTextChanged(Editable s) {

			}
		});

		btnFinish.setOnClickListener(new OnClickListener() {
			public void onClick(View arg0) {
				finish();
			}
		});
		Toast.makeText(getApplicationContext(), "onCreate", 1).show();
	}

	@Override
	protected void onPause() {
		super.onPause();
		//saveDataFromCurrentState();
		Toast.makeText(this, "onPause", 1).show();
		// SharedPreferences myFile1 = getSharedPreferences("myFile1",
		// Activity.MODE_PRIVATE);
		// SharedPreferences.Editor myEditor = myFile1.edit();
		// String temp = txtMsg.getText().toString();
		// myEditor.putString("mydata", temp);
		// myEditor.commit();
	}

	private void saveDataFromCurrentState() {
		SharedPreferences myPrefs = getSharedPreferences(MYPREFSID, actMode);
		SharedPreferences.Editor myEditor = myPrefs.edit();
		myEditor.putString("txt", txtMsg.getText().toString());
		myEditor.commit();
	}

	@Override
	protected void onRestart() {
		super.onRestart();
		Toast.makeText(this, "onRestart", 1).show();
	}

	@Override
	protected void onResume() {
		super.onResume();
		Toast.makeText(this, "onResume", 1).show();
		SharedPreferences myFile = getSharedPreferences("myFile1",
				Activity.MODE_PRIVATE);
		if ((myFile != null) && (myFile.contains("mydata"))) {
			String temp = myFile.getString("mydata", "***");
			txtMsg.setText(temp);
		}
	}

	@Override
	protected void onStart() {
		// TODO Auto-generated method stub
		super.onStart();
		//updateFromSavedState();
		Toast.makeText(this, "onStart", 1).show();
	}

	private void updateFromSavedState() {
		SharedPreferences myPrefs = getSharedPreferences(MYPREFSID, actMode);
		if ((myPrefs != null) && (myPrefs.contains("txt"))) {
			String text = myPrefs.getString("txt", "");
			txtMsg.setText(text);
		}
	}

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		Toast.makeText(this, "onDestroy", 1).show();
	}

	@Override
	protected void onStop() {
		// TODO Auto-generated method stub
		super.onStop();
		Toast.makeText(this, "onStop", 1).show();
	}

	protected void clearMyPreferences() {
		SharedPreferences myPrefs = getSharedPreferences(MYPREFSID, actMode);
		SharedPreferences.Editor myEditor = myPrefs.edit();
		myEditor.clear();
		myEditor.commit();
	}

	/* (non-Javadoc)
	 * @see android.app.Activity#onRestoreInstanceState(android.os.Bundle)
	 */
	@Override
	protected void onRestoreInstanceState(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onRestoreInstanceState(savedInstanceState);
		Toast.makeText(getBaseContext(),
				"onRestoreInstanceState ...BUNDLING",
				Toast.LENGTH_LONG).show();
	}

	/* (non-Javadoc)
	 * @see android.app.Activity#onSaveInstanceState(android.os.Bundle)
	 */
	@Override
	protected void onSaveInstanceState(Bundle outState) {
		// TODO Auto-generated method stub
		super.onSaveInstanceState(outState);
		Toast.makeText(getBaseContext(),
				"onSaveInstanceState ...BUNDLING",
				Toast.LENGTH_LONG).show();
	}
	
	
}